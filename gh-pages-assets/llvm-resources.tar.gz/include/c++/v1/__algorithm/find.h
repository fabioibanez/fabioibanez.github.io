// -*- C++ -*-
//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _LIBCPP___ALGORITHM_FIND_H
#define _LIBCPP___ALGORITHM_FIND_H

#include <__algorithm/find_segment_if.h>
#include <__algorithm/min.h>
#include <__algorithm/simd_utils.h>
#include <__algorithm/unwrap_iter.h>
#include <__bit/countr.h>
#include <__bit/invert_if.h>
#include <__config>
#include <__cstddef/size_t.h>
#include <__functional/identity.h>
#include <__fwd/bit_reference.h>
#include <__iterator/segmented_iterator.h>
#include <__string/constexpr_c_functions.h>
#include <__type_traits/enable_if.h>
#include <__type_traits/invoke.h>
#include <__type_traits/is_constant_evaluated.h>
#include <__type_traits/is_equality_comparable.h>
#include <__type_traits/is_integral.h>
#include <__type_traits/is_signed.h>
#include <__utility/move.h>
#include <limits>

#if _LIBCPP_HAS_WIDE_CHARACTERS
#  include <cwchar>
#endif

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

_LIBCPP_PUSH_MACROS
#include <__undef_macros>

_LIBCPP_BEGIN_NAMESPACE_STD

// generic implementation
template <class _Iter, class _Sent, class _Tp, class _Proj>
_LIBCPP_HIDE_FROM_ABI _LIBCPP_CONSTEXPR_SINCE_CXX14 _Iter
__find_loop(_Iter __first, _Sent __last, const _Tp& __value, _Proj& __proj) {
  for (; __first != __last; ++__first)
    if (std::__invoke(__proj, *__first) == __value)
      break;
  return __first;
}

template <class _Iter, class _Sent, class _Tp, class _Proj>
_LIBCPP_HIDE_FROM_ABI _LIBCPP_CONSTEXPR_SINCE_CXX14 _Iter
__find(_Iter __first, _Sent __last, const _Tp& __value, _Proj& __proj) {
  return std::__find_loop(std::move(__first), std::move(__last), __value, __proj);
}

#if _LIBCPP_VECTORIZE_ALGORITHMS
template <class _Tp, class _Up>
[[__nodiscard__]] _LIBCPP_HIDE_FROM_ABI
_LIBCPP_CONSTEXPR_SINCE_CXX14 _Tp* __find_vectorized(_Tp* __first, _Tp* __last, _Up __value) {
  if (!__libcpp_is_constant_evaluated()) {
    constexpr size_t __unroll_count = 4;
    constexpr size_t __vec_size     = __native_vector_size<_Tp>;
    using __vec                     = __simd_vector<_Tp, __vec_size>;

    auto __orig_first = __first;

    auto __values = static_cast<__simd_vector<_Tp, __vec_size>>(__value); // broadcast the value
    while (static_cast<size_t>(__last - __first) >= __unroll_count * __vec_size) [[__unlikely__]] {
      __vec __lhs[__unroll_count];

      for (size_t __i = 0; __i != __unroll_count; ++__i)
        __lhs[__i] = std::__load_vector<__vec>(__first + __i * __vec_size);

      for (size_t __i = 0; __i != __unroll_count; ++__i) {
        if (auto __cmp_res = __lhs[__i] == __values; std::__any_of(__cmp_res)) {
          auto __offset = __i * __vec_size + std::__find_first_set(__cmp_res);
          return __first + __offset;
        }
      }

      __first += __unroll_count * __vec_size;
    }

    // check the remaining 0-3 vectors
    while (static_cast<size_t>(__last - __first) >= __vec_size) {
      if (auto __cmp_res = std::__load_vector<__vec>(__first) == __values; std::__any_of(__cmp_res)) {
        return __first + std::__find_first_set(__cmp_res);
      }
      __first += __vec_size;
    }

    if (__last - __first == 0)
      return __first;

    // Check if we can load elements in front of the current pointer. If that's the case load a vector at
    // (last - vector_size) to check the remaining elements
    if (static_cast<size_t>(__first - __orig_first) >= __vec_size) {
      __first = __last - __vec_size;
      return __first + std::__find_first_set(std::__load_vector<__vec>(__first) == __values);
    }
  }

  __identity __proj;
  return std::__find_loop(__first, __last, __value, __proj);
}
#endif

#ifndef _LIBCPP_CXX03_LANG
// trivially equality comparable implementations
template <class _Tp,
          class _Up,
          class _Proj,
          __enable_if_t<__is_identity<_Proj>::value && __is_trivially_equality_comparable_v<_Tp, _Up>, int> = 0>
_LIBCPP_HIDE_FROM_ABI _LIBCPP_CONSTEXPR_SINCE_CXX14 _Tp* __find(_Tp* __first, _Tp* __last, const _Up& __value, _Proj&) {
  if constexpr (sizeof(_Tp) == 1) {
    if (auto __ret = std::__constexpr_memchr(__first, __value, __last - __first))
      return __ret;
    return __last;
  }
#  if _LIBCPP_HAS_WIDE_CHARACTERS
  else if constexpr (sizeof(_Tp) == sizeof(wchar_t) && _LIBCPP_ALIGNOF(_Tp) >= _LIBCPP_ALIGNOF(wchar_t)) {
    if (auto __ret = std::__constexpr_wmemchr(__first, __value, __last - __first))
      return __ret;
    return __last;
  }
#  endif
#  if _LIBCPP_VECTORIZE_ALGORITHMS
  else if constexpr (is_integral<_Tp>::value) {
    return std::__find_vectorized(__first, __last, __value);
  }
#  endif
  else {
    __identity __proj;
    return std::__find_loop(__first, __last, __value, __proj);
  }
}
#endif

// TODO: This should also be possible to get right with different signedness
// cast integral types to allow vectorization
template <class _Tp,
          class _Up,
          class _Proj,
          __enable_if_t<__is_identity<_Proj>::value && !__is_trivially_equality_comparable_v<_Tp, _Up> &&
                            is_integral<_Tp>::value && is_integral<_Up>::value &&
                            is_signed<_Tp>::value == is_signed<_Up>::value,
                        int> = 0>
_LIBCPP_HIDE_FROM_ABI _LIBCPP_CONSTEXPR_SINCE_CXX14 _Tp*
__find(_Tp* __first, _Tp* __last, const _Up& __value, _Proj& __proj) {
  if (__value < numeric_limits<_Tp>::min() || __value > numeric_limits<_Tp>::max())
    return __last;
  return std::__find(__first, __last, _Tp(__value), __proj);
}

// __bit_iterator implementation
template <bool _ToFind, class _Cp, bool _IsConst>
_LIBCPP_CONSTEXPR_SINCE_CXX20 _LIBCPP_HIDE_FROM_ABI __bit_iterator<_Cp, _IsConst>
__find_bool(__bit_iterator<_Cp, _IsConst> __first, typename __size_difference_type_traits<_Cp>::size_type __n) {
  using _It            = __bit_iterator<_Cp, _IsConst>;
  using __storage_type = typename _It::__storage_type;

  const int __bits_per_word = _It::__bits_per_word;
  // do first partial word
  if (__first.__ctz_ != 0) {
    __storage_type __clz_f = static_cast<__storage_type>(__bits_per_word - __first.__ctz_);
    __storage_type __dn    = std::min(__clz_f, __n);
    __storage_type __m     = std::__middle_mask<__storage_type>(__clz_f - __dn, __first.__ctz_);
    __storage_type __b     = std::__invert_if<!_ToFind>(*__first.__seg_) & __m;
    if (__b)
      return _It(__first.__seg_, static_cast<unsigned>(std::__countr_zero(__b)));
    if (__n == __dn)
      return __first + __n;
    __n -= __dn;
    ++__first.__seg_;
  }
  // do middle whole words
  for (; __n >= __bits_per_word; ++__first.__seg_, __n -= __bits_per_word) {
    __storage_type __b = std::__invert_if<!_ToFind>(*__first.__seg_);
    if (__b)
      return _It(__first.__seg_, static_cast<unsigned>(std::__countr_zero(__b)));
  }
  // do last partial word
  if (__n > 0) {
    __storage_type __m = std::__trailing_mask<__storage_type>(__bits_per_word - __n);
    __storage_type __b = std::__invert_if<!_ToFind>(*__first.__seg_) & __m;
    if (__b)
      return _It(__first.__seg_, static_cast<unsigned>(std::__countr_zero(__b)));
  }
  return _It(__first.__seg_, static_cast<unsigned>(__n));
}

template <class _Cp, bool _IsConst, class _Tp, class _Proj, __enable_if_t<__is_identity<_Proj>::value, int> = 0>
inline _LIBCPP_HIDE_FROM_ABI _LIBCPP_CONSTEXPR_SINCE_CXX20 __bit_iterator<_Cp, _IsConst>
__find(__bit_iterator<_Cp, _IsConst> __first, __bit_iterator<_Cp, _IsConst> __last, const _Tp& __value, _Proj&) {
  if (static_cast<bool>(__value))
    return std::__find_bool<true>(
        __first, static_cast<typename __size_difference_type_traits<_Cp>::size_type>(__last - __first));
  return std::__find_bool<false>(
      __first, static_cast<typename __size_difference_type_traits<_Cp>::size_type>(__last - __first));
}

// segmented iterator implementation

template <class _SegmentedIterator,
          class _Tp,
          class _Proj,
          __enable_if_t<__is_segmented_iterator_v<_SegmentedIterator>, int> = 0>
_LIBCPP_HIDE_FROM_ABI _LIBCPP_CONSTEXPR_SINCE_CXX14 _SegmentedIterator
__find(_SegmentedIterator __first, _SegmentedIterator __last, const _Tp& __value, _Proj& __proj) {
  using __local_iterator = typename __segmented_iterator_traits<_SegmentedIterator>::__local_iterator;
  return std::__find_segment_if(
      std::move(__first),
      std::move(__last),
      [&__value](__local_iterator __lfirst, __local_iterator __llast, _Proj& __lproj) {
        return std::__rewrap_iter(
            __lfirst, std::__find(std::__unwrap_iter(__lfirst), std::__unwrap_iter(__llast), __value, __lproj));
      },
      __proj);
}

// public API
template <class _InputIterator, class _Tp>
[[__nodiscard__]] inline _LIBCPP_HIDE_FROM_ABI _LIBCPP_CONSTEXPR_SINCE_CXX20 _InputIterator
find(_InputIterator __first, _InputIterator __last, const _Tp& __value) {
  __identity __proj;
  return std::__rewrap_iter(
      __first, std::__find(std::__unwrap_iter(__first), std::__unwrap_iter(__last), __value, __proj));
}

_LIBCPP_END_NAMESPACE_STD

_LIBCPP_POP_MACROS

#endif // _LIBCPP___ALGORITHM_FIND_H
